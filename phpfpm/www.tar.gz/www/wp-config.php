<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpressdb' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'password' );

/** MySQL hostname */
define( 'DB_HOST', 'docker-mariadb' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '09[F(Qx.{;VqR=]m7r}4[(`0({=U_y:Lf_6ia&4moi${bS{zK2?<FUgdYESpo=^H' );
define( 'SECURE_AUTH_KEY',  '6 R#r,Ww9Q?,mc5.g>iVzkEP|+dK_x}]n)BpUIW|ahc1u]{HHwUsxJWIUd9(W2W-' );
define( 'LOGGED_IN_KEY',    'ap:T7vo2vxPQXfp|uFYJYt0uJ+K8 @ax{@7/O#Zc$U32IiB(OfWpNAe:~79=!`W{' );
define( 'NONCE_KEY',        'i=>bsL}psGCI!eaact(gIvg@d-|4(g+EHMrs[T&x*ECk.O0s{@:+JLz5XY0h]PmC' );
define( 'AUTH_SALT',        'e hWL.QsqQp[_sZ&Q1#$gE6b#1Y6k _&o:?[$nmeOV%)P-20%:;qoJ 7W+3j6t21' );
define( 'SECURE_AUTH_SALT', '16o(K{u$q&#/,_YX 7(8jrcG&#.?oq${G&w9(:<&,Y/T)+v)e^@Lf95hXE2@gtBD' );
define( 'LOGGED_IN_SALT',   ';WRO|mE3.n>(X,ET)d}/q MDGHPR<._x0/fQ>J})2O9<DO{VPSwM6J;Cxw`6BmIM' );
define( 'NONCE_SALT',       'pobu1fV!KE#h)PM3A)>*R{r!F[=^vbQ8IG&A4R`nWU-+u0Px=~>_f#@aww$O#r#u' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
